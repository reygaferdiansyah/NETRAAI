import streamlit as st
import requests
import base64
import sympy as sp  # For mathematical formula detection

#credentials
AZURE_OPENAI_API_KEY = "6ec8053e11d34bb6acc03330388ba9db"
AZURE_OPENAI_ENDPOINT = "https://talenta-ai-2024-batch2.openai.azure.com/"
SPEECH_KEY = "232d072838de4797908c738708459c41"
SERVICE_REGION = "southeastasia"

# Function to perform OCR using OpenAI (Note: OpenAI does not provide direct OCR service)
def ocr_image(image_content):
    image_data = base64.b64encode(image_content).decode('utf-8')

    headers = {
        "Content-Type": "application/json",
        "api-key": AZURE_OPENAI_API_KEY,
    }

    payload = {
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image_url",
                        "image_url": {
                            "text": "Kamu adalah seorang guru dengan murid yang memiliki keterbatasan penglihatan (tuna netra)."
                                    "Oleh karena itu, kamu harus menjelaskan teks dalam bentuk narasi."
                                    " jika soal ujian sampaikan soalnya saja, tidak perlu di jawab.",
                            "url": f"data:image/jpeg;base64,{image_data}"
                        }
                    }
                ]
            }
        ],
        "temperature": 0.5,
        "top_p": 0.95,
        "max_tokens": 800
    }

    try:
        response = requests.post(
            f"{AZURE_OPENAI_ENDPOINT}/openai/deployments/gpt-4o/chat/completions?api-version=2024-02-15-preview",
            headers=headers, json=payload)
        response.raise_for_status()

    except requests.RequestException as e:
        raise SystemExit(f"Failed to make the request. Error: {e}")

    res = response.json()
    ocr_text = res['choices'][0]['message']['content']

    return ocr_text


# Function to convert text to speech using Azure Speech SDK
def text_to_speech(content):
    import azure.cognitiveservices.speech as speechsdk

    speech_config = speechsdk.SpeechConfig(subscription=SPEECH_KEY, region=SERVICE_REGION)
    audio_config = speechsdk.audio.AudioOutputConfig(filename="output_audio.wav")  # Save audio to file

    speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_config)
    result = speech_synthesizer.speak_text_async(content).get()

    return "output_audio.wav"


# Streamlit app
def main():
    st.title("OpenAI OCR to Speech with Formula Detection")

    # Centering the main content
    st.markdown("<h1 style='text-align: center;'>Upload File</h1>", unsafe_allow_html=True)
    uploaded_file = st.file_uploader("Choose a PDF or Image file", type=['pdf', 'jpg', 'jpeg', 'png'])

    if uploaded_file is not None:
        file_content = uploaded_file.read()
        file_type = uploaded_file.type

        if file_type.startswith('image/'):
            # Perform OCR on image using OpenAI (replace with actual OCR logic)
            ocr_result = ocr_image(file_content)

            # Convert OCR result to speech
            audio_file = text_to_speech(ocr_result)
            st.audio(audio_file, format='audio/wav')

        elif file_type == 'application/pdf':
            # Process PDF pages to images and perform OCR on each page (similar logic as before)
            st.info("Processing PDF...")

        else:
            st.warning("Unsupported file format. Please upload a PDF or an image.")

    st.markdown("<p style='text-align: center;'>Powered by OpenAI and Azure Speech SDK</p>", unsafe_allow_html=True)


if __name__ == '__main__':
    main()
